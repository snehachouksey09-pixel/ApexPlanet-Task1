let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
let list = document.getElementById("list");

function showTasks() {
  list.innerHTML = "";
  tasks.forEach((task, index) => {
    list.innerHTML += `
      <li>
        ${task}
        <button onclick="deleteTask(${index})">❌</button>
      </li>
    `;
  });
}

function addTask() {
  let taskInput = document.getElementById("task");
  if (taskInput.value === "") return;

  tasks.push(taskInput.value);
  localStorage.setItem("tasks", JSON.stringify(tasks));
  taskInput.value = "";
  showTasks();
}

function deleteTask(index) {
  tasks.splice(index, 1);
  localStorage.setItem("tasks", JSON.stringify(tasks));
  showTasks();
}

showTasks();
