document.getElementById("btn").addEventListener("click", function () {
    alert("Hello! You clicked the button 🎉");
});
