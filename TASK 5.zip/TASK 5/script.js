// Dark Mode
const themeBtn = document.getElementById("themeBtn");

if(themeBtn){
  themeBtn.onclick = () => {
    document.body.classList.toggle("dark");
  };
}

// Projects (Dynamic)
const projects = [
  { title: "To-Do App", desc: "Task manager using LocalStorage" },
  { title: "Calculator", desc: "JavaScript based calculator" },
  { title: "Portfolio", desc: "Personal responsive website" }
];

const container = document.getElementById("projectContainer");

if(container){
  projects.forEach(p => {
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `<h3>${p.title}</h3><p>${p.desc}</p>`;
    container.appendChild(div);
  });
}

// Contact Form
const form = document.getElementById("contactForm");

if(form){
  form.addEventListener("submit", e => {
    e.preventDefault();
    document.getElementById("msg").innerText =
      "Message sent successfully!";
    form.reset();
  });
}
