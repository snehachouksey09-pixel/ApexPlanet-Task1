// FORM VALIDATION
document.getElementById("contactForm").addEventListener("submit", function(e) {
    e.preventDefault();

    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let error = document.getElementById("error");

    if (name === "" || email === "") {
        error.innerHTML = "All fields are required";
    } 
    else if (!email.includes("@")) {
        error.innerHTML = "Invalid email format";
    } 
    else {
        error.innerHTML = "Form Submitted Successfully!";
        error.style.color = "green";
    }
});

// TO-DO LIST (DOM MANIPULATION)
function addTask() {
    let taskInput = document.getElementById("taskInput");
    let taskList = document.getElementById("taskList");

    if (taskInput.value === "") return;

    let li = document.createElement("li");
    li.innerHTML = taskInput.value;

    li.onclick = function() {
        this.remove();
    };

    taskList.appendChild(li);
    taskInput.value = "";
}
